﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_140324
{
    internal class Produto
    {
        public double preço { get; private set; }
        public string nome { get; private set; }

        public Produto(double preço, string nome)
        {
            this.preço = preço;
            this.nome = nome;
        }
    }
}
