﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_140324
{
    internal class Program
    {
       
        static void Main(string[] args)
        {
        Dictionary<string, Produto> Produtos = new Dictionary<string, Produto>()
        {
            {"Banana", new Produto(5, "Banana") },
            {"Maça", new Produto(5, "Maça") },
            {"Limão", new Produto(3, "Limão") },
            {"Beterraba", new Produto(8, "Beterraba") },
            {"Abacaxi", new Produto(15, "Abacaxi") },
            {"Melancia", new Produto(20, "Melancia") },
            {"Manga", new Produto(7, "Manga") },
            {"Pessego", new Produto(4, "Pessego") }



        };


        Pedido pedido = new Pedido();

            pedido.AdicionarItem(Produtos["Maça"], 20, 0);
            pedido.AdicionarItem(Produtos["Banana"], 20, 0);
            pedido.AdicionarItem(Produtos["Limão"], 20, 0);
            pedido.AdicionarItem(Produtos["Beterraba"], 20, 0);
            pedido.AdicionarItem(Produtos["Melancia"], 20, 0);

            Console.WriteLine("Preço: {0} ", pedido.valor);

        }
    }
}
