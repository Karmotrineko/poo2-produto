﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_140324
{
    internal class Pedido
    {
        List<Item> Items = new List<Item>();
        public double valor;
        public void AdicionarItem(Produto produto, int quantidade, int desconto)
        {
            if(Items.All(Item => Item.produto.nome != produto.nome ))
            {
                Item a = new Item(produto, quantidade, desconto);
                Items.Add(a);
                RecalcularValor();
            }
            else
            {
                Console.WriteLine("Já existe esse produto no pedido, deseja adicioná-lo em um item pre-existente? S para sim e N para não.");
                int a = 1;
                while(a == 1 )
                {
                    string res = Console.ReadLine();
                    res.ToUpper();
                    if (res == "S")
                    {
                        a++;
                        Console.WriteLine("Adicionando e retornando para Menu.");
                        Item item = Items.Find(Item => Item.produto.nome == produto.nome);
                        item.AdicionarProduto(quantidade);
                        item.ReceberDesconto(desconto);
                        RecalcularValor();
                    }
                    else if (res == "N")
                    {
                        a++;
                        Console.WriteLine("Ok, retornando para Menu.");
                    }
                    else
                    {
                        Console.WriteLine("Resposta não reconhecida, favor responder com S ou N.");
                    }
                }
            }

        }
        public void RecalcularValor()
        {
            valor = 0;
            foreach(Item i in Items)
            {
                this.valor += i.valor;
            }
        }
        public void AdicionarProduto(Produto produto, int quantidade)
        {
            Items.Find(Item => Item.produto.nome == produto.nome).AdicionarProduto(quantidade);
            RecalcularValor();
        }
        public void RemoverProduto(Produto produto, int quantidade)
        {
            Items.Find(Item => Item.produto.nome == produto.nome).RemoverProduto(quantidade);
            RecalcularValor();
        }
        public void ReceberDesconto(Produto produto, int desconto)
        {
            Items.Find(Item => Item.produto.nome == produto.nome).ReceberDesconto(desconto);
            RecalcularValor();
        }

    }
}
