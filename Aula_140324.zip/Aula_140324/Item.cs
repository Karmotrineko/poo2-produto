﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_140324
{
    internal class Item
    {
        public Produto produto { get; private set; }
        public int quantidade { get; set; }
        public int desconto { get; set; }
        public double valor { get; set; }

        public Item(Produto produto, int quantidade, int desconto)
        {
            this.produto = produto;
            this.quantidade = quantidade;
            this.desconto = desconto;
            this.valor = produto.preço * quantidade * (100 - this.desconto) / 100;

        }
        public void ReceberDesconto(int desconto)
        {
            this.desconto = desconto;
            valor = produto.preço * this.quantidade * (100 - this.desconto) / 100;
        }
        public void AdicionarProduto(int quantidade)
        {
            this.quantidade = this.quantidade + quantidade;
            this.valor = produto.preço * this.quantidade * (100 - this.desconto) / 100;
        }
        public void RemoverProduto(int quantidade)
        {
            if(this.quantidade - quantidade < 0)
            {
                Console.WriteLine("Valor final negativo!!");
            }
            else
            {
                this.quantidade = this.quantidade - quantidade;
                this.valor = produto.preço * this.quantidade * (100 - this.desconto) / 100;
            }
        }

    }
}
